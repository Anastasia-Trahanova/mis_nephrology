"""
Назначение файла: сборка context для форм нового пациента и повторного приёма.

Этот сервис не содержит SQL напрямую. Он собирает справочники, пациента,
последний приём, истории анализов и словари, которые нужны HTML-формам.

Что выполняет файл:
- get_new_patient_context() — context для страницы добавления нового пациента;
- get_new_appointment_context(patient_id) — context для нового приёма существующего пациента;
- _group_icd10_diagnoses_for_form() — группировка МКБ-10 диагнозов для формы.

Что редактировать здесь:
- какие справочники передаются в формы;
- какие данные прошлого приёма подставляются в повторный приём;
- какие истории анализов доступны врачу при заполнении формы.

Что не редактировать здесь:
- SQL — он в app/repositories;
- внешний вид формы — он в app/templates/appointment_form;
- сохранение формы — оно в appointment_save_service.py и patient_appointment_service.py.
"""

from __future__ import annotations

from app.db.connection import get_db_connection
from app.repositories.appointments import (
    _fetch_appointment_diet,
    _fetch_appointment_medications,
    _fetch_last_appointment_data,
    _fetch_patient_appointments,
)
from app.repositories.lab_history import (
    _fetch_patient_albuminuria_history,
    _fetch_patient_biochemistry_history,
    _fetch_patient_cbc_history,
    _fetch_patient_metrics_history,
    _fetch_patient_ultrasound_history,
    _fetch_patient_urinalysis_history,
)
from app.repositories.patients import _fetch_patient_by_id
from app.repositories.reference_data import (
    _fetch_appointment_icd10_diagnoses,
    _fetch_branches,
    _fetch_doctors,
    _fetch_icd10_diagnoses,
    _fetch_locations_by_branch,
    _fetch_medications_dictionary,
)


def _group_icd10_diagnoses_for_form(icd10_diagnoses):
    """Группирует МКБ-10 диагнозы для подстановки в форму повторного приёма."""
    result = {
        "main": None,
        "complications": [],
        "comorbidities": [],
    }

    for item in icd10_diagnoses:
        if item["diagnosis_type"] == "main" and result["main"] is None:
            result["main"] = item
        elif item["diagnosis_type"] == "complication":
            result["complications"].append(item)
        elif item["diagnosis_type"] == "comorbidity":
            result["comorbidities"].append(item)

    return result


def get_new_appointment_context(patient_id: int):
    """Собирает данные для формы нового приёма одним соединением к БД."""
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            patient = _fetch_patient_by_id(cur, patient_id)
            if not patient:
                return None

            appointments = _fetch_patient_appointments(cur, patient_id)
            last_appointment = _fetch_last_appointment_data(cur, patient_id)
            last_appointment_id = appointments[0]["appointment_id"] if appointments else None

            last_icd10_diagnoses = []
            last_icd10_diagnoses_grouped = {
                "main": None,
                "complications": [],
                "comorbidities": [],
            }

            if last_appointment_id:
                last_icd10_diagnoses = _fetch_appointment_icd10_diagnoses(cur, last_appointment_id)
                last_icd10_diagnoses_grouped = _group_icd10_diagnoses_for_form(last_icd10_diagnoses)

            return {
                "patient": patient,
                "appointments": appointments,
                "branches": _fetch_branches(cur),
                "doctors": _fetch_doctors(cur),
                "locations": _fetch_locations_by_branch(cur),
                "last_appointment": last_appointment,
                "last_icd10_diagnoses": last_icd10_diagnoses,
                "last_icd10_diagnoses_grouped": last_icd10_diagnoses_grouped,
                "last_medications": _fetch_appointment_medications(cur, last_appointment_id) if last_appointment_id else [],
                "last_diet_info": _fetch_appointment_diet(cur, last_appointment_id) if last_appointment_id else None,
                "cbc_history": _fetch_patient_cbc_history(cur, patient_id),
                "biochemistry_history": _fetch_patient_biochemistry_history(cur, patient_id),
                "urinalysis_history": _fetch_patient_urinalysis_history(cur, patient_id),
                "albuminuria_history": _fetch_patient_albuminuria_history(cur, patient_id),
                "ultrasound_history": _fetch_patient_ultrasound_history(cur, patient_id),
                "metrics_history": _fetch_patient_metrics_history(cur, patient_id),
                "icd10_diagnoses": _fetch_icd10_diagnoses(cur),
                "medications_dictionary": _fetch_medications_dictionary(cur),
            }


def get_new_patient_context():
    """Собирает данные для формы нового пациента одним соединением к БД."""
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            return {
                "branches": _fetch_branches(cur),
                "doctors": _fetch_doctors(cur),
                "locations": _fetch_locations_by_branch(cur),
                "icd10_diagnoses": _fetch_icd10_diagnoses(cur),
                "medications_dictionary": _fetch_medications_dictionary(cur),
            }
